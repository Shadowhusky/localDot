# dot breakout

A small Breakout game for the browser. The ball is dot: a pearly white ball with two black oval
eyes that look the way it is moving.

## Play

    npm install
    npm run dev

Then open the printed URL (default http://localhost:5173).

- move the paddle with the mouse or the left/right arrow keys (`A`/`D` also work)
- `Space` (or click) launches dot
- `P` pauses, `R` restarts

## Rules

Five rows of ten colourful bricks, top row worth the most (50 down to 10 points). Losing dot off
the bottom costs a life; three lives. Clear every brick for the win screen, run out of lives for
the game over screen. Dot speeds up slightly with every brick it breaks.

## Layout

- `src/game.ts` - state, physics and rules (no DOM, no drawing)
- `src/render.ts` - all canvas drawing, including dot and its eyes
- `src/main.ts` - canvas sizing, input handling and the animation loop
- `src/style.css` - page around the canvas

`window.dotBreakout.snapshot()` returns a read-only copy of the current state (phase, score,
lives, ball and paddle position); it is handy for automated play tests.

    npm run build      # tsc + vite build into dist/
    npx tsc --noEmit   # type check only
