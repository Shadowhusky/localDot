import './style.css'
import {
  H,
  W,
  createGame,
  launch,
  restart,
  snapshot,
  togglePause,
  update,
  type Input,
  type Snapshot,
} from './game'
import { draw } from './render'

declare global {
  interface Window {
    dotBreakout: { snapshot: () => Snapshot }
  }
}

const foundCanvas = document.querySelector<HTMLCanvasElement>('#game')
if (!foundCanvas) throw new Error('game canvas not found')
const foundContext = foundCanvas.getContext('2d')
if (!foundContext) throw new Error('2d canvas context unavailable')

const canvas: HTMLCanvasElement = foundCanvas
const context: CanvasRenderingContext2D = foundContext

const game = createGame()
const input: Input = { pointerX: null, left: false, right: false }
const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)')

function fitCanvas(): void {
  const dpr = Math.min(window.devicePixelRatio || 1, 2)
  canvas.width = Math.round(W * dpr)
  canvas.height = Math.round(H * dpr)
  context.setTransform(dpr, 0, 0, dpr, 0, 0)
}

function toWorldX(event: PointerEvent): number {
  const rect = canvas.getBoundingClientRect()
  return ((event.clientX - rect.left) / rect.width) * W
}

function isLaunchKey(key: string): boolean {
  return key === ' ' || key === 'Spacebar' || key === 'Enter'
}

fitCanvas()
window.addEventListener('resize', fitCanvas)

canvas.addEventListener('pointermove', (event) => {
  input.pointerX = toWorldX(event)
  input.left = false
  input.right = false
})

canvas.addEventListener('pointerdown', (event) => {
  event.preventDefault()
  input.pointerX = toWorldX(event)
  launch(game)
})

window.addEventListener('keydown', (event) => {
  const key = event.key
  if (key === 'ArrowLeft' || key === 'a' || key === 'A') {
    input.left = true
    input.pointerX = null
    event.preventDefault()
  } else if (key === 'ArrowRight' || key === 'd' || key === 'D') {
    input.right = true
    input.pointerX = null
    event.preventDefault()
  } else if (isLaunchKey(key)) {
    event.preventDefault()
    launch(game)
  } else if (key === 'p' || key === 'P' || key === 'Escape') {
    togglePause(game)
  } else if (key === 'r' || key === 'R') {
    restart(game)
  }
})

window.addEventListener('keyup', (event) => {
  const key = event.key
  if (key === 'ArrowLeft' || key === 'a' || key === 'A') input.left = false
  else if (key === 'ArrowRight' || key === 'd' || key === 'D') input.right = false
})

window.addEventListener('blur', () => {
  input.left = false
  input.right = false
})

let last = performance.now()

function frame(now: number): void {
  const dt = Math.min((now - last) / 1000, 1 / 30)
  last = now
  update(game, dt, input)
  draw(context, game, now / 1000, reducedMotion.matches)
  requestAnimationFrame(frame)
}

requestAnimationFrame(frame)

window.dotBreakout = { snapshot: () => snapshot(game) }
