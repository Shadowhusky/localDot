import { H, PADDLE_Y, ROW_COLORS, W, type Game } from './game'

const FONT = "system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif"

function roundRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number,
): void {
  const radius = Math.min(r, w / 2, h / 2)
  ctx.beginPath()
  ctx.moveTo(x + radius, y)
  ctx.lineTo(x + w - radius, y)
  ctx.quadraticCurveTo(x + w, y, x + w, y + radius)
  ctx.lineTo(x + w, y + h - radius)
  ctx.quadraticCurveTo(x + w, y + h, x + w - radius, y + h)
  ctx.lineTo(x + radius, y + h)
  ctx.quadraticCurveTo(x, y + h, x, y + h - radius)
  ctx.lineTo(x, y + radius)
  ctx.quadraticCurveTo(x, y, x + radius, y)
  ctx.closePath()
}

function shade(hex: string, amount: number): string {
  const value = parseInt(hex.slice(1), 16)
  const r = (value >> 16) & 255
  const g = (value >> 8) & 255
  const b = value & 255
  const mix = (c: number): number =>
    Math.round(amount < 0 ? c * (1 + amount) : c + (255 - c) * amount)
  return 'rgb(' + mix(r) + ', ' + mix(g) + ', ' + mix(b) + ')'
}

function drawBackground(ctx: CanvasRenderingContext2D): void {
  const sky = ctx.createLinearGradient(0, 0, 0, H)
  sky.addColorStop(0, '#0b1123')
  sky.addColorStop(0.55, '#121834')
  sky.addColorStop(1, '#1a1f3d')
  ctx.fillStyle = sky
  ctx.fillRect(0, 0, W, H)

  const glow = ctx.createRadialGradient(W / 2, -140, 40, W / 2, -140, 640)
  glow.addColorStop(0, 'rgba(150, 190, 255, 0.22)')
  glow.addColorStop(1, 'rgba(150, 190, 255, 0)')
  ctx.fillStyle = glow
  ctx.fillRect(0, 0, W, H)

  ctx.strokeStyle = 'rgba(255, 255, 255, 0.07)'
  ctx.lineWidth = 2
  ctx.beginPath()
  ctx.moveTo(1, 0)
  ctx.lineTo(1, H)
  ctx.moveTo(W - 1, 0)
  ctx.lineTo(W - 1, H)
  ctx.stroke()
}

function drawBricks(ctx: CanvasRenderingContext2D, game: Game): void {
  for (const brick of game.bricks) {
    if (!brick.alive) continue
    const base = ROW_COLORS[brick.row] ?? ROW_COLORS[ROW_COLORS.length - 1]

    const face = ctx.createLinearGradient(0, brick.y, 0, brick.y + brick.h)
    face.addColorStop(0, base)
    face.addColorStop(1, shade(base, -0.3))
    ctx.fillStyle = face
    roundRect(ctx, brick.x, brick.y, brick.w, brick.h, 6)
    ctx.fill()

    ctx.fillStyle = 'rgba(255, 255, 255, 0.32)'
    roundRect(ctx, brick.x + 5, brick.y + 4, brick.w - 10, 3, 1.5)
    ctx.fill()
  }
}

function drawPaddle(ctx: CanvasRenderingContext2D, game: Game): void {
  const paddle = game.paddle
  const y = paddle.y
  const body = ctx.createLinearGradient(0, y, 0, y + paddle.h)
  body.addColorStop(0, '#ffffff')
  body.addColorStop(0.45, '#dfe8f7')
  body.addColorStop(1, '#93a9c9')

  ctx.save()
  if (game.flash > 0) {
    ctx.shadowColor = 'rgba(180, 214, 255, 0.9)'
    ctx.shadowBlur = 26 * game.flash
  } else {
    ctx.shadowColor = 'rgba(120, 170, 255, 0.45)'
    ctx.shadowBlur = 14
  }
  ctx.fillStyle = body
  roundRect(ctx, paddle.x, y, paddle.w, paddle.h, paddle.h / 2)
  ctx.fill()
  ctx.restore()

  ctx.fillStyle = 'rgba(255, 255, 255, 0.8)'
  roundRect(ctx, paddle.x + 12, y + 3, paddle.w - 24, 3, 1.5)
  ctx.fill()
}

export function drawDot(
  ctx: CanvasRenderingContext2D,
  game: Game,
  t: number,
  pulse: boolean,
): void {
  const ball = game.ball
  const look = game.look
  const x = ball.x
  const y = ball.y
  const r = ball.r

  if (pulse) {
    const ring = r + 6 + Math.sin(t * 3) * 2.5
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.22)'
    ctx.lineWidth = 1.5
    ctx.beginPath()
    ctx.arc(x, y, ring, 0, Math.PI * 2)
    ctx.stroke()
  }

  ctx.save()
  ctx.shadowColor = 'rgba(214, 232, 255, 0.75)'
  ctx.shadowBlur = 18
  const pearl = ctx.createRadialGradient(x - r * 0.38, y - r * 0.45, r * 0.12, x, y, r * 1.12)
  pearl.addColorStop(0, '#ffffff')
  pearl.addColorStop(0.45, '#f3f6fb')
  pearl.addColorStop(0.8, '#dbe3ee')
  pearl.addColorStop(1, '#bcc7d8')
  ctx.fillStyle = pearl
  ctx.beginPath()
  ctx.arc(x, y, r, 0, Math.PI * 2)
  ctx.fill()
  ctx.restore()

  ctx.strokeStyle = 'rgba(255, 255, 255, 0.7)'
  ctx.lineWidth = 1
  ctx.beginPath()
  ctx.arc(x, y, r - 0.5, 0, Math.PI * 2)
  ctx.stroke()

  const angle = Math.atan2(look.y, look.x)
  const spread = 0.6
  const eyeDistance = r * 0.48
  const eyeRx = 2.7
  const eyeRy = 3.5

  for (const side of [-1, 1]) {
    const a = angle + side * spread
    const ex = x + Math.cos(a) * eyeDistance
    const ey = y + Math.sin(a) * eyeDistance

    ctx.save()
    ctx.translate(ex, ey)
    ctx.rotate(a)
    ctx.fillStyle = '#12151d'
    ctx.beginPath()
    ctx.ellipse(0, 0, eyeRx, eyeRy, 0, 0, Math.PI * 2)
    ctx.fill()
    ctx.restore()

    ctx.fillStyle = 'rgba(255, 255, 255, 0.92)'
    ctx.beginPath()
    ctx.arc(
      ex + look.x * 0.9 - look.y * 0.5,
      ey + look.y * 0.9 + look.x * 0.5,
      0.85,
      0,
      Math.PI * 2,
    )
    ctx.fill()
  }
}

function drawHud(ctx: CanvasRenderingContext2D, game: Game): void {
  ctx.textBaseline = 'middle'
  ctx.textAlign = 'left'
  ctx.fillStyle = 'rgba(226, 236, 255, 0.6)'
  ctx.font = '600 13px ' + FONT
  ctx.fillText('SCORE', 44, 30)
  ctx.fillStyle = '#ffffff'
  ctx.font = '700 26px ' + FONT
  ctx.fillText(String(game.score), 44, 55)

  ctx.textAlign = 'right'
  ctx.fillStyle = 'rgba(226, 236, 255, 0.6)'
  ctx.font = '600 13px ' + FONT
  ctx.fillText('LIVES', W - 44, 30)

  for (let i = 0; i < game.lives; i++) {
    const x = W - 46 - i * 26
    const y = 44
    const dot = ctx.createRadialGradient(x - 2.5, y - 3, 1, x, y, 9)
    dot.addColorStop(0, '#ffffff')
    dot.addColorStop(1, '#b9c6da')
    ctx.fillStyle = dot
    ctx.beginPath()
    ctx.arc(x, y, 8.5, 0, Math.PI * 2)
    ctx.fill()
  }

  ctx.fillStyle = 'rgba(226, 236, 255, 0.42)'
  ctx.font = '500 13px ' + FONT
  ctx.fillText(String(game.remaining) + ' bricks left', W - 44, H - 24)

  ctx.textAlign = 'left'
  ctx.textBaseline = 'alphabetic'
}

function drawPanel(
  ctx: CanvasRenderingContext2D,
  title: string,
  subtitle: string,
  lines: string[],
  cta: string,
  t: number,
  pulse: boolean,
): void {
  ctx.fillStyle = 'rgba(6, 9, 20, 0.72)'
  ctx.fillRect(0, 0, W, H)

  const cardW = 540
  const cardH = 150 + lines.length * 26 + 54
  const cardX = (W - cardW) / 2
  const cardY = (H - cardH) / 2 - 24

  ctx.save()
  ctx.shadowColor = 'rgba(0, 0, 0, 0.5)'
  ctx.shadowBlur = 40
  ctx.fillStyle = 'rgba(18, 24, 46, 0.95)'
  roundRect(ctx, cardX, cardY, cardW, cardH, 20)
  ctx.fill()
  ctx.restore()

  ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)'
  ctx.lineWidth = 1
  roundRect(ctx, cardX + 0.5, cardY + 0.5, cardW - 1, cardH - 1, 20)
  ctx.stroke()

  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'

  ctx.fillStyle = '#ffffff'
  ctx.font = '700 40px ' + FONT
  ctx.fillText(title, W / 2, cardY + 62)

  ctx.fillStyle = 'rgba(190, 208, 240, 0.82)'
  ctx.font = '500 16px ' + FONT
  ctx.fillText(subtitle, W / 2, cardY + 100)

  ctx.font = '500 15px ' + FONT
  lines.forEach((line, index) => {
    ctx.fillStyle = 'rgba(214, 226, 248, 0.78)'
    ctx.fillText(line, W / 2, cardY + 140 + index * 26)
  })

  const alpha = pulse ? 0.55 + 0.45 * (0.5 + 0.5 * Math.sin(t * 3.4)) : 1
  ctx.fillStyle = 'rgba(140, 200, 255, ' + alpha + ')'
  ctx.font = '600 17px ' + FONT
  ctx.fillText(cta, W / 2, cardY + cardH - 30)

  ctx.textAlign = 'left'
  ctx.textBaseline = 'alphabetic'
}

function drawReadyHint(ctx: CanvasRenderingContext2D, game: Game, t: number): void {
  const alpha = 0.5 + 0.5 * (0.5 + 0.5 * Math.sin(t * 3.4))
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  ctx.fillStyle = 'rgba(200, 220, 255, ' + alpha + ')'
  ctx.font = '600 16px ' + FONT
  ctx.fillText('Press Space to launch', game.paddle.x + game.paddle.w / 2, PADDLE_Y - 46)
  ctx.textAlign = 'left'
  ctx.textBaseline = 'alphabetic'
}

export function draw(
  ctx: CanvasRenderingContext2D,
  game: Game,
  t: number,
  reducedMotion: boolean,
): void {
  drawBackground(ctx)
  drawBricks(ctx, game)
  drawPaddle(ctx, game)
  drawDot(ctx, game, t, !reducedMotion && game.phase !== 'playing')
  drawHud(ctx, game)

  const animate = !reducedMotion

  if (game.phase === 'title') {
    drawPanel(
      ctx,
      'DOT BREAKOUT',
      'dot is the ball, keep it in play',
      ['Move: mouse or arrow keys', 'Launch: Space    Pause: P'],
      'Press Space or click to start',
      t,
      animate,
    )
  } else if (game.phase === 'paused') {
    drawPanel(ctx, 'PAUSED', 'take your time', [], 'Press P to resume', t, false)
  } else if (game.phase === 'won') {
    drawPanel(
      ctx,
      'YOU WIN',
      'every brick cleared, score ' + game.score,
      ['Lives left: ' + game.lives],
      'Press R to play again',
      t,
      animate,
    )
  } else if (game.phase === 'lost') {
    drawPanel(
      ctx,
      'GAME OVER',
      'score ' + game.score + ', ' + game.remaining + ' bricks left',
      ['Lives left: 0'],
      'Press R to play again',
      t,
      animate,
    )
  } else if (game.phase === 'ready') {
    drawReadyHint(ctx, game, animate ? t : 0)
  }
}
