export const W = 960
export const H = 600

export type Phase = 'title' | 'ready' | 'playing' | 'paused' | 'won' | 'lost'

export interface Vec {
  x: number
  y: number
}

export interface Ball extends Vec {
  vx: number
  vy: number
  r: number
}

export interface Paddle extends Vec {
  w: number
  h: number
}

export interface Brick extends Vec {
  w: number
  h: number
  row: number
  alive: boolean
}

export interface Input {
  pointerX: number | null
  left: boolean
  right: boolean
}

export interface Snapshot {
  phase: Phase
  score: number
  lives: number
  remaining: number
  ballX: number
  ballY: number
  paddleX: number
}

export interface Game {
  phase: Phase
  ball: Ball
  paddle: Paddle
  bricks: Brick[]
  score: number
  lives: number
  remaining: number
  look: Vec
  flash: number
}

export const COLS = 10
export const ROWS = 5
export const START_LIVES = 3

const BRICK_H = 28
const BRICK_GAP = 6
const BRICK_SIDE = 48
const BRICK_TOP = 76

const PADDLE_SPEED = 760
const BALL_R = 8
const BASE_SPEED = 350
const SPEED_PER_BRICK = 6
const MAX_SPEED = 640
const MAX_BOUNCE_ANGLE = (60 * Math.PI) / 180

export const BRICK_W = (W - BRICK_SIDE * 2 - BRICK_GAP * (COLS - 1)) / COLS

export const ROW_COLORS = ['#ff5f7e', '#ffa651', '#ffe27a', '#5fe0a8', '#6cb8ff']

export const PADDLE_Y = 546
export const PADDLE_W = 132
export const PADDLE_H = 14

function clamp(value: number, min: number, max: number): number {
  return value < min ? min : value > max ? max : value
}

function brickScore(row: number): number {
  return (ROWS - row) * 10
}

function makeBricks(): Brick[] {
  const bricks: Brick[] = []
  for (let row = 0; row < ROWS; row++) {
    for (let col = 0; col < COLS; col++) {
      bricks.push({
        x: BRICK_SIDE + col * (BRICK_W + BRICK_GAP),
        y: BRICK_TOP + row * (BRICK_H + BRICK_GAP),
        w: BRICK_W,
        h: BRICK_H,
        row,
        alive: true,
      })
    }
  }
  return bricks
}

export function createGame(): Game {
  const game: Game = {
    phase: 'title',
    ball: { x: W / 2, y: PADDLE_Y - BALL_R - 1, vx: 0, vy: 0, r: BALL_R },
    paddle: { x: W / 2 - PADDLE_W / 2, y: PADDLE_Y, w: PADDLE_W, h: PADDLE_H },
    bricks: makeBricks(),
    score: 0,
    lives: START_LIVES,
    remaining: COLS * ROWS,
    look: { x: 0, y: -1 },
    flash: 0,
  }
  parkBall(game)
  return game
}

function parkBall(game: Game): void {
  const { ball, paddle } = game
  ball.vx = 0
  ball.vy = 0
  ball.x = paddle.x + paddle.w / 2
  ball.y = paddle.y - ball.r - 1
  game.look.x = 0
  game.look.y = -1
}

function speedFor(game: Game): number {
  const destroyed = COLS * ROWS - game.remaining
  return Math.min(MAX_SPEED, BASE_SPEED + destroyed * SPEED_PER_BRICK)
}

function rescale(game: Game): void {
  const { ball } = game
  const current = Math.hypot(ball.vx, ball.vy)
  if (current === 0) return
  const target = speedFor(game)
  ball.vx = (ball.vx / current) * target
  ball.vy = (ball.vy / current) * target
}

export function launch(game: Game): void {
  if (game.phase !== 'title' && game.phase !== 'ready') return
  const angle = (Math.random() - 0.5) * (Math.PI / 3)
  const speed = speedFor(game)
  game.ball.vx = Math.sin(angle) * speed
  game.ball.vy = -Math.cos(angle) * speed
  game.phase = 'playing'
}

export function restart(game: Game): void {
  game.phase = 'title'
  game.bricks = makeBricks()
  game.score = 0
  game.lives = START_LIVES
  game.remaining = COLS * ROWS
  game.flash = 0
  game.paddle.x = W / 2 - game.paddle.w / 2
  parkBall(game)
}

export function togglePause(game: Game): void {
  if (game.phase === 'playing') game.phase = 'paused'
  else if (game.phase === 'paused') game.phase = 'playing'
}

export function update(game: Game, dt: number, input: Input): void {
  if (game.flash > 0) game.flash = Math.max(0, game.flash - dt * 4)
  smoothLook(game, dt)

  if (game.phase === 'title' || game.phase === 'ready') {
    movePaddle(game, dt, input)
    parkBall(game)
    return
  }
  if (game.phase !== 'playing') return

  movePaddle(game, dt, input)

  const { ball } = game
  const travel = Math.hypot(ball.vx, ball.vy) * dt
  const steps = Math.max(1, Math.ceil(travel / (ball.r * 0.5)))
  const sdt = dt / steps
  for (let i = 0; i < steps; i++) {
    if (game.phase !== 'playing') break
    substep(game, sdt)
  }
}

function smoothLook(game: Game, dt: number): void {
  const { ball, look } = game
  const speed = Math.hypot(ball.vx, ball.vy)
  let tx = look.x
  let ty = look.y
  if (speed > 1) {
    tx = ball.vx / speed
    ty = ball.vy / speed
  } else if (game.phase === 'title' || game.phase === 'ready') {
    tx = 0
    ty = -1
  }
  const k = 1 - Math.exp(-dt * 12)
  look.x += (tx - look.x) * k
  look.y += (ty - look.y) * k
  const mag = Math.hypot(look.x, look.y) || 1
  look.x /= mag
  look.y /= mag
}

function movePaddle(game: Game, dt: number, input: Input): void {
  const { paddle } = game
  if (input.left !== input.right) {
    paddle.x += (input.left ? -1 : 1) * PADDLE_SPEED * dt
  } else if (input.pointerX !== null) {
    paddle.x = input.pointerX - paddle.w / 2
  }
  paddle.x = clamp(paddle.x, 0, W - paddle.w)
}

function substep(game: Game, dt: number): void {
  const { ball } = game
  ball.x += ball.vx * dt
  ball.y += ball.vy * dt

  if (ball.x - ball.r < 0) {
    ball.x = ball.r
    ball.vx = Math.abs(ball.vx)
  } else if (ball.x + ball.r > W) {
    ball.x = W - ball.r
    ball.vx = -Math.abs(ball.vx)
  }
  if (ball.y - ball.r < 0) {
    ball.y = ball.r
    ball.vy = Math.abs(ball.vy)
  }

  if (ball.vy > 0 && hitsPaddle(game)) bounceOffPaddle(game)
  hitBricks(game)

  if (ball.y - ball.r > H) loseLife(game)
}

function hitsPaddle(game: Game): boolean {
  const { ball, paddle } = game
  if (ball.y >= paddle.y + paddle.h) return false
  const cx = clamp(ball.x, paddle.x, paddle.x + paddle.w)
  const cy = clamp(ball.y, paddle.y, paddle.y + paddle.h)
  const dx = ball.x - cx
  const dy = ball.y - cy
  return dx * dx + dy * dy <= ball.r * ball.r
}

function bounceOffPaddle(game: Game): void {
  const { ball, paddle } = game
  const offset = (ball.x - (paddle.x + paddle.w / 2)) / (paddle.w / 2)
  const angle = clamp(offset, -1, 1) * MAX_BOUNCE_ANGLE
  const speed = Math.max(Math.hypot(ball.vx, ball.vy), speedFor(game))
  ball.vx = Math.sin(angle) * speed
  ball.vy = -Math.cos(angle) * speed
  ball.y = paddle.y - ball.r - 0.5
  game.flash = 1
}

function hitBricks(game: Game): void {
  const { ball } = game
  for (const brick of game.bricks) {
    if (!brick.alive) continue
    const cx = clamp(ball.x, brick.x, brick.x + brick.w)
    const cy = clamp(ball.y, brick.y, brick.y + brick.h)
    const dx = ball.x - cx
    const dy = ball.y - cy
    if (dx * dx + dy * dy > ball.r * ball.r) continue

    const bx = brick.x + brick.w / 2
    const by = brick.y + brick.h / 2
    const overlapX = brick.w / 2 + ball.r - Math.abs(ball.x - bx)
    const overlapY = brick.h / 2 + ball.r - Math.abs(ball.y - by)

    if (overlapX < overlapY) {
      ball.vx = ball.x < bx ? -Math.abs(ball.vx) : Math.abs(ball.vx)
      ball.x += ball.x < bx ? -overlapX : overlapX
    } else {
      ball.vy = ball.y < by ? -Math.abs(ball.vy) : Math.abs(ball.vy)
      ball.y += ball.y < by ? -overlapY : overlapY
    }

    brick.alive = false
    game.remaining--
    game.score += brickScore(brick.row)

    if (game.remaining === 0) {
      game.phase = 'won'
      ball.vx = 0
      ball.vy = 0
      return
    }
    rescale(game)
    return
  }
}

function loseLife(game: Game): void {
  game.lives--
  if (game.lives > 0) {
    game.phase = 'ready'
    parkBall(game)
    return
  }
  game.phase = 'lost'
  game.ball.vx = 0
  game.ball.vy = 0
}

export function snapshot(game: Game): Snapshot {
  return {
    phase: game.phase,
    score: game.score,
    lives: game.lives,
    remaining: game.remaining,
    ballX: game.ball.x,
    ballY: game.ball.y,
    paddleX: game.paddle.x,
  }
}
